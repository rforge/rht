residuals.svystat.rob <-
function(object, ...){
   attr(object, "resid")
}
